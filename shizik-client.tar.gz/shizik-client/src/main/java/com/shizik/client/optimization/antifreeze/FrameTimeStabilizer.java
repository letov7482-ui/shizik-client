package com.shizik.client.optimization.antifreeze;

import com.shizik.client.config.ShizikConfig;
import com.shizik.client.util.PerformanceProfiler;

import java.util.ArrayDeque;
import java.util.Deque;

/**
 * Frame Time Stabilizer — сглаживает время кадра, используя скользящее среднее.
 * Выявляет выбросы (спайки) времени кадра и сигнализирует о нестабильности
 * для адаптивных систем.
 */
public class FrameTimeStabilizer {

    private static final int WINDOW_SIZE = 30;
    private static final double SPIKE_FACTOR = 2.5;

    private final ShizikConfig config;
    private final PerformanceProfiler profiler;

    private boolean enabled = false;
    private final Deque<double[]> samples = new ArrayDeque<>(WINDOW_SIZE + 1);
    private double smoothedFrameMs = 16.67;
    private boolean spikeDetected = false;
    private int spikeCount = 0;

    public FrameTimeStabilizer(ShizikConfig config, PerformanceProfiler profiler) {
        this.config = config;
        this.profiler = profiler;
    }

    public void init() {
        enabled = config.isFrameTimeStabilizer();
        if (enabled) {
            com.shizik.client.ShizikClient.LOGGER.info("[FrameStabilizer] Инициализирован, окно: {} кадров",
                    WINDOW_SIZE);
        }
    }

    public void onFrameEnd() {
        if (!enabled) return;

        double rawMs = profiler.getAverageFrameMs();
        addSample(rawMs);

        double avg = computeAverage();
        spikeDetected = rawMs > avg * SPIKE_FACTOR && avg > 0.5;
        if (spikeDetected) {
            spikeCount++;
        }

        // Экспоненциальное скользящее среднее (EMA) для сглаживания
        double alpha = 0.15;
        smoothedFrameMs = alpha * rawMs + (1.0 - alpha) * smoothedFrameMs;
    }

    private void addSample(double ms) {
        samples.addLast(new double[]{ms});
        while (samples.size() > WINDOW_SIZE) {
            samples.pollFirst();
        }
    }

    private double computeAverage() {
        if (samples.isEmpty()) return smoothedFrameMs;
        double sum = 0.0;
        for (double[] s : samples) sum += s[0];
        return sum / samples.size();
    }

    public double getSmoothedFrameMs() { return smoothedFrameMs; }
    public boolean isSpikeDetected() { return spikeDetected; }
    public int getSpikeCount() { return spikeCount; }
    public boolean isEnabled() { return enabled; }
    public double getSmoothedFps() {
        return smoothedFrameMs > 0.01 ? 1000.0 / smoothedFrameMs : 0.0;
    }
}
