package com.shizik.client.optimization.fps;

import com.shizik.client.config.ShizikConfig;
import com.shizik.client.render.RenderCapabilityDetector;
import net.minecraft.item.ItemStack;

import java.util.HashMap;
import java.util.Map;

/**
 * Smart Item Render — кэширует хэши ItemStack для пропуска лишних
 * перерасчётов моделей предметов в инвентаре и в руке.
 * Использует DataComponentMap (Minecraft 1.21.4) для вычисления ключа кэша.
 */
public class SmartItemRenderer {

    private static final int CACHE_CAPACITY = 512;

    private final ShizikConfig config;
    private final RenderCapabilityDetector renderDetector;

    private boolean enabled = false;
    private final Map<Integer, Long> renderCache = new HashMap<>(CACHE_CAPACITY);
    private long currentFrame = 0L;

    public SmartItemRenderer(ShizikConfig config, RenderCapabilityDetector renderDetector) {
        this.config = config;
        this.renderDetector = renderDetector;
    }

    public void init() {
        enabled = config.isSmartItemRender();
        if (enabled) {
            com.shizik.client.ShizikClient.LOGGER.info("[SmartItemRender] Инициализирован, ёмкость кэша: {}", CACHE_CAPACITY);
        }
    }

    public void onFrameStart() {
        currentFrame++;
        if (currentFrame % 200 == 0) {
            trimCache();
        }
    }

    /**
     * Проверяет, нужно ли пересчитывать рендер для данного ItemStack.
     * @return true если рендер уже актуален в этом кадре
     */
    public boolean isCachedThisFrame(ItemStack stack) {
        if (!enabled || stack == null || stack.isEmpty()) return false;
        int key = computeKey(stack);
        Long lastFrame = renderCache.get(key);
        if (lastFrame != null && lastFrame == currentFrame) {
            return true;
        }
        renderCache.put(key, currentFrame);
        return false;
    }

    private int computeKey(ItemStack stack) {
        int h = stack.getItem().hashCode();
        h = 31 * h + stack.getCount();
        // В Minecraft 1.21.4 используем компонентную систему вместо NBT
        h = 31 * h + stack.getComponents().hashCode();
        return h;
    }

    private void trimCache() {
        if (renderCache.size() <= CACHE_CAPACITY) return;
        long cutoff = currentFrame - 60L;
        renderCache.entrySet().removeIf(e -> e.getValue() < cutoff);
        if (renderCache.size() > CACHE_CAPACITY) {
            renderCache.clear();
        }
    }

    public void invalidate() {
        renderCache.clear();
    }

    public boolean isEnabled() { return enabled; }
    public int getCacheSize() { return renderCache.size(); }
}
