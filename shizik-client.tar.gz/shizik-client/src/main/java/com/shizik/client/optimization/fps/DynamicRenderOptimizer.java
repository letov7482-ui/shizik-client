package com.shizik.client.optimization.fps;

import com.shizik.client.config.ShizikConfig;
import com.shizik.client.render.RenderCapabilityDetector;
import com.shizik.client.util.PerformanceProfiler;
import net.minecraft.client.MinecraftClient;

/**
 * Dynamic Render — автоматически регулирует дальность рендера в зависимости от FPS.
 * Снижает дальность при падении производительности и восстанавливает при улучшении.
 */
public class DynamicRenderOptimizer {

    private static final int CHECK_INTERVAL_TICKS = 40;
    private static final int MIN_RENDER_DISTANCE = 2;
    private static final int STEP = 1;

    private final ShizikConfig config;
    private final RenderCapabilityDetector renderDetector;
    private final PerformanceProfiler profiler;

    private boolean enabled = false;
    private int originalRenderDistance = 8;
    private int tickCounter = 0;
    private int adjustedDistance = 8;
    private boolean restored = true;

    public DynamicRenderOptimizer(ShizikConfig config,
                                   RenderCapabilityDetector renderDetector,
                                   PerformanceProfiler profiler) {
        this.config = config;
        this.renderDetector = renderDetector;
        this.profiler = profiler;
    }

    public void init() {
        enabled = config.isDynamicRender() && !renderDetector.isSafeMode();
        if (!enabled && config.isDynamicRender() && renderDetector.isSafeMode()) {
            ShizikClient_log("DynamicRender отключён — безопасный режим рендера");
        }
    }

    private void ShizikClient_log(String msg) {
        com.shizik.client.ShizikClient.LOGGER.info("[DynamicRender] {}", msg);
    }

    public void onFrameStart() {
        if (!enabled) return;

        MinecraftClient client = MinecraftClient.getInstance();
        if (client == null || client.options == null || client.world == null) return;

        tickCounter++;
        if (tickCounter < CHECK_INTERVAL_TICKS) return;
        tickCounter = 0;

        int currentFps = profiler.getCurrentFps();
        int target = config.getTargetFps();

        if (currentFps == 0) return;

        int currentDistance = client.options.getViewDistance().getValue();

        if (currentFps < target * 0.7 && currentDistance > MIN_RENDER_DISTANCE) {
            adjustedDistance = Math.max(MIN_RENDER_DISTANCE, currentDistance - STEP);
            if (adjustedDistance != currentDistance) {
                client.options.getViewDistance().setValue(adjustedDistance);
                restored = false;
            }
        } else if (currentFps > target * 0.9 && !restored) {
            adjustedDistance = Math.min(originalRenderDistance, currentDistance + STEP);
            client.options.getViewDistance().setValue(adjustedDistance);
            if (adjustedDistance >= originalRenderDistance) {
                restored = true;
            }
        }
    }

    public void captureOriginal() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client != null && client.options != null) {
            originalRenderDistance = client.options.getViewDistance().getValue();
            adjustedDistance = originalRenderDistance;
        }
    }

    public void restoreOriginal() {
        if (!enabled || restored) return;
        MinecraftClient client = MinecraftClient.getInstance();
        if (client != null && client.options != null) {
            client.options.getViewDistance().setValue(originalRenderDistance);
            restored = true;
        }
    }

    public boolean isEnabled() { return enabled; }
    public int getAdjustedDistance() { return adjustedDistance; }
}
