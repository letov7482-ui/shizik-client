package com.shizik.client.optimization.antifreeze;

import com.shizik.client.config.ShizikConfig;
import com.shizik.client.util.PerformanceProfiler;

/**
 * MicroFreeze Shield — проактивно обнаруживает угрозу микрофриза
 * (когда тик занимает слишком долго) и инициирует превентивные меры:
 * уведомляет другие подсистемы о необходимости снизить нагрузку.
 */
public class MicroFreezeShield {

    private static final int ALERT_HISTORY = 10;

    private final ShizikConfig config;
    private final FreezeMonitor freezeMonitor;
    private final PerformanceProfiler profiler;

    private boolean enabled = false;
    private boolean shieldActive = false;
    private int consecutiveSpikeCount = 0;
    private int alertCount = 0;
    private long shieldActivatedAt = 0L;
    private static final long SHIELD_DURATION_MS = 2000L;

    public MicroFreezeShield(ShizikConfig config, FreezeMonitor freezeMonitor, PerformanceProfiler profiler) {
        this.config = config;
        this.freezeMonitor = freezeMonitor;
        this.profiler = profiler;
    }

    public void init() {
        enabled = config.isMicroFreezeShield();
        if (enabled) {
            com.shizik.client.ShizikClient.LOGGER.info("[MicroFreezeShield] Инициализирован, порог: {}мс",
                    config.getFreezeThresholdMs());
        }
    }

    /** Вызывается каждый кадр — проверяет угрозу микрофриза. */
    public void evaluate() {
        if (!enabled) return;

        double frameMs = profiler.getAverageFrameMs();
        long threshold = config.getFreezeThresholdMs();

        if (frameMs > threshold) {
            consecutiveSpikeCount++;
        } else {
            consecutiveSpikeCount = Math.max(0, consecutiveSpikeCount - 1);
        }

        boolean threatDetected = consecutiveSpikeCount >= 3;

        if (threatDetected && !shieldActive) {
            activateShield();
        } else if (!threatDetected && shieldActive) {
            long now = System.currentTimeMillis();
            if (now - shieldActivatedAt >= SHIELD_DURATION_MS) {
                deactivateShield();
            }
        }
    }

    private void activateShield() {
        shieldActive = true;
        shieldActivatedAt = System.currentTimeMillis();
        alertCount++;
        com.shizik.client.ShizikClient.LOGGER.debug(
                "[MicroFreezeShield] Щит активирован (угроза #{}) — рамочное время: {:.1f}мс",
                alertCount, profiler.getAverageFrameMs());
    }

    private void deactivateShield() {
        shieldActive = false;
        consecutiveSpikeCount = 0;
        com.shizik.client.ShizikClient.LOGGER.debug("[MicroFreezeShield] Щит деактивирован");
    }

    public boolean isShieldActive() { return shieldActive; }
    public boolean isEnabled() { return enabled; }
    public int getAlertCount() { return alertCount; }
}
