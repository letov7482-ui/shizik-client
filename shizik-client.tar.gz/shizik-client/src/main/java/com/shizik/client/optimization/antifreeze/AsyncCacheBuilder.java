package com.shizik.client.optimization.antifreeze;

import com.shizik.client.config.ShizikConfig;

import java.util.concurrent.*;
import java.util.function.Supplier;

/**
 * Async Cache Builder — выполняет тяжёлые операции построения кэшей
 * в фоновом потоке, не блокируя главный поток рендера.
 */
public class AsyncCacheBuilder {

    private final ShizikConfig config;
    private boolean enabled = false;
    private ExecutorService executor;

    public AsyncCacheBuilder(ShizikConfig config) {
        this.config = config;
    }

    public void init() {
        enabled = config.isAsyncCacheBuilder();
        if (enabled) {
            executor = Executors.newSingleThreadExecutor(r -> {
                Thread t = new Thread(r, "ShizikClient-AsyncCache");
                t.setDaemon(true);
                t.setPriority(Thread.MIN_PRIORITY + 1);
                return t;
            });
            com.shizik.client.ShizikClient.LOGGER.info("[AsyncCache] Инициализирован, фоновый поток запущен");
        }
    }

    /**
     * Отправляет задачу в фоновый поток.
     * @param task задача построения кэша
     * @return Future с результатом, или completedFuture(null) если отключён
     */
    public <T> CompletableFuture<T> submit(Supplier<T> task) {
        if (!enabled || executor == null || executor.isShutdown()) {
            return CompletableFuture.completedFuture(null);
        }
        return CompletableFuture.supplyAsync(task, executor)
                .exceptionally(ex -> {
                    com.shizik.client.ShizikClient.LOGGER.warn("[AsyncCache] Ошибка в фоновой задаче: {}",
                            ex.getMessage());
                    return null;
                });
    }

    /**
     * Отправляет задачу без возврата результата.
     */
    public void submitVoid(Runnable task) {
        if (!enabled || executor == null || executor.isShutdown()) {
            task.run();
            return;
        }
        executor.submit(() -> {
            try {
                task.run();
            } catch (Exception e) {
                com.shizik.client.ShizikClient.LOGGER.warn("[AsyncCache] Ошибка в фоновой задаче: {}",
                        e.getMessage());
            }
        });
    }

    public void shutdown() {
        if (executor != null && !executor.isShutdown()) {
            executor.shutdownNow();
        }
    }

    public boolean isEnabled() { return enabled; }
}
