/**
 * Подсистемы Anti Freeze для предотвращения микрофризов и стабилизации производительности.
 */
package com.shizik.client.optimization.antifreeze;
