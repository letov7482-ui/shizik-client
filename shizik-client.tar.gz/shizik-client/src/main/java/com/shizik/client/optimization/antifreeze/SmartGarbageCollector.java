package com.shizik.client.optimization.antifreeze;

import com.shizik.client.config.ShizikConfig;
import com.shizik.client.util.PerformanceProfiler;

/**
 * Smart Garbage Collection — запускает GC в промежутке между кадрами,
 * когда потребление памяти высокое, но кадр уже завершён.
 * Предотвращает автоматические GC-паузы в середине рендера.
 */
public class SmartGarbageCollector {

    private static final double MEMORY_TRIGGER_RATIO = 0.80;
    private static final double MEMORY_SAFE_RATIO = 0.60;

    private final ShizikConfig config;
    private final PerformanceProfiler profiler;

    private boolean enabled = false;
    private int tickCounter = 0;
    private int gcCount = 0;
    private long lastGcTime = 0L;

    public SmartGarbageCollector(ShizikConfig config, PerformanceProfiler profiler) {
        this.config = config;
        this.profiler = profiler;
    }

    public void init() {
        enabled = config.isSmartGC();
        if (enabled) {
            com.shizik.client.ShizikClient.LOGGER.info("[SmartGC] Инициализирован, интервал: {} тиков", config.getGcIntervalTicks());
        }
    }

    public void onTick() {
        if (!enabled) return;
        tickCounter++;

        if (tickCounter >= config.getGcIntervalTicks()) {
            tickCounter = 0;
            checkAndCollect();
        }
    }

    private void checkAndCollect() {
        Runtime rt = Runtime.getRuntime();
        long total = rt.totalMemory();
        long free = rt.freeMemory();
        long max = rt.maxMemory();
        double usedRatio = (double)(total - free) / max;

        if (usedRatio >= MEMORY_TRIGGER_RATIO) {
            long now = System.currentTimeMillis();
            // Не запускаем GC чаще раза в 5 секунд
            if (now - lastGcTime > 5000L) {
                System.gc();
                lastGcTime = now;
                gcCount++;
                double usedMb = (total - free) / (1024.0 * 1024.0);
                com.shizik.client.ShizikClient.LOGGER.debug(
                        "[SmartGC] GC #{} запущен (использовано {:.1f}MB, {:.0f}%)",
                        gcCount, usedMb, usedRatio * 100);
            }
        }
    }

    /** Вызывается при завершении кадра — безопасное место для GC. */
    public void onFrameEnd() {
        if (!enabled) return;
        Runtime rt = Runtime.getRuntime();
        double usedRatio = (double)(rt.totalMemory() - rt.freeMemory()) / rt.maxMemory();
        if (usedRatio >= MEMORY_TRIGGER_RATIO && (System.currentTimeMillis() - lastGcTime > 10000L)) {
            System.gc();
            lastGcTime = System.currentTimeMillis();
            gcCount++;
        }
    }

    public boolean isEnabled() { return enabled; }
    public int getGcCount() { return gcCount; }
}
