package com.shizik.client.optimization.antifreeze;

import com.shizik.client.config.ShizikConfig;
import com.shizik.client.render.RenderCapabilityDetector;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Runnable;

/**
 * Texture Upload Scheduler — ставит операции загрузки текстур в очередь
 * и выполняет их пакетно, предотвращая пики кадрового времени
 * при одновременной загрузке множества текстур.
 */
public class TextureUploadScheduler {

    private static final int MAX_UPLOADS_PER_FRAME = 4;
    private static final int MAX_QUEUE_SIZE = 256;

    private final ShizikConfig config;
    private final RenderCapabilityDetector renderDetector;

    private boolean enabled = false;
    private final Deque<Runnable> uploadQueue = new ArrayDeque<>(MAX_QUEUE_SIZE);
    private final AtomicInteger uploadedThisFrame = new AtomicInteger(0);

    public TextureUploadScheduler(ShizikConfig config, RenderCapabilityDetector renderDetector) {
        this.config = config;
        this.renderDetector = renderDetector;
    }

    public void init() {
        enabled = config.isTextureUploadScheduler() && !renderDetector.isSafeMode();
        if (enabled) {
            com.shizik.client.ShizikClient.LOGGER.info("[TextureScheduler] Инициализирован, лимит/кадр: {}",
                    MAX_UPLOADS_PER_FRAME);
        }
    }

    /**
     * Ставит операцию загрузки текстуры в очередь.
     * Если очередь переполнена — выполняет задачу немедленно.
     */
    public void schedule(Runnable uploadTask) {
        if (!enabled) {
            uploadTask.run();
            return;
        }
        if (uploadQueue.size() >= MAX_QUEUE_SIZE) {
            // Очередь полна — выполняем немедленно
            uploadTask.run();
            return;
        }
        uploadQueue.addLast(uploadTask);
    }

    /** Вызывается в начале каждого кадра — сбрасывает счётчик. */
    public void onFrameStart() {
        uploadedThisFrame.set(0);
    }

    /** Вызывается после рендера — выполняет пакет задач из очереди. */
    public void flushBatch() {
        if (!enabled || uploadQueue.isEmpty()) return;

        int limit = MAX_UPLOADS_PER_FRAME;
        int done = 0;
        while (done < limit && !uploadQueue.isEmpty()) {
            Runnable task = uploadQueue.pollFirst();
            if (task != null) {
                try {
                    task.run();
                    done++;
                    uploadedThisFrame.incrementAndGet();
                } catch (Exception e) {
                    com.shizik.client.ShizikClient.LOGGER.warn("[TextureScheduler] Ошибка загрузки текстуры: {}",
                            e.getMessage());
                }
            }
        }
    }

    public int getQueueSize() { return uploadQueue.size(); }
    public int getUploadedThisFrame() { return uploadedThisFrame.get(); }
    public boolean isEnabled() { return enabled; }
}
