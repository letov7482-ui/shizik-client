/**
 * Подсистемы FPS Boost для повышения производительности рендера.
 */
package com.shizik.client.optimization.fps;
