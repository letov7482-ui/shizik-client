package com.shizik.client.config;

import com.google.gson.*;
import net.fabricmc.loader.api.FabricLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;

/**
 * Конфигурация мода с автоматическим сохранением в JSON.
 */
public class ShizikConfig {

    private static final Logger LOGGER = LoggerFactory.getLogger("ShizikConfig");
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path CONFIG_PATH = FabricLoader.getInstance()
            .getConfigDir().resolve("shizik_client.json");

    // FPS Boost
    private boolean dynamicRender = true;
    private boolean entityCulling = true;
    private boolean battleMode = true;
    private boolean smartItemRender = true;
    private boolean adaptiveAnimation = true;
    private boolean invisibleChunkCache = true;

    // Anti Freeze
    private boolean smartGC = true;
    private boolean chunkLoadQueue = true;
    private boolean entityUpdateSplit = true;
    private boolean textureUploadScheduler = true;
    private boolean asyncCacheBuilder = true;
    private boolean frameTimeStabilizer = true;
    private boolean microFreezeShield = true;
    private boolean resourcePreloader = true;
    private boolean memoryDefragmentation = true;
    private boolean freezeMonitor = true;
    private boolean adaptivePerformanceAI = true;

    // Render
    private boolean safeRenderMode = false;

    // HUD
    private boolean showHud = true;

    // Tuning
    private int targetFps = 60;
    private int gcIntervalTicks = 200;
    private int entitySplitBatchSize = 10;
    private long freezeThresholdMs = 50;
    private int chunkQueueBatchSize = 4;
    private int defragIntervalTicks = 6000;

    public static ShizikConfig load() {
        if (Files.exists(CONFIG_PATH)) {
            try (Reader reader = new InputStreamReader(
                    Files.newInputStream(CONFIG_PATH), StandardCharsets.UTF_8)) {
                ShizikConfig cfg = GSON.fromJson(reader, ShizikConfig.class);
                if (cfg != null) {
                    LOGGER.info("[ShizikConfig] Конфигурация загружена из {}", CONFIG_PATH);
                    return cfg;
                }
            } catch (Exception e) {
                LOGGER.warn("[ShizikConfig] Ошибка загрузки конфигурации, используются значения по умолчанию: {}", e.getMessage());
            }
        }
        ShizikConfig defaultCfg = new ShizikConfig();
        defaultCfg.save();
        return defaultCfg;
    }

    public void save() {
        try {
            Files.createDirectories(CONFIG_PATH.getParent());
            try (Writer writer = new OutputStreamWriter(
                    Files.newOutputStream(CONFIG_PATH), StandardCharsets.UTF_8)) {
                GSON.toJson(this, writer);
            }
        } catch (IOException e) {
            LOGGER.warn("[ShizikConfig] Не удалось сохранить конфигурацию: {}", e.getMessage());
        }
    }

    // FPS getters/setters
    public boolean isDynamicRender() { return dynamicRender; }
    public void setDynamicRender(boolean v) { dynamicRender = v; save(); }

    public boolean isEntityCulling() { return entityCulling; }
    public void setEntityCulling(boolean v) { entityCulling = v; save(); }

    public boolean isBattleMode() { return battleMode; }
    public void setBattleMode(boolean v) { battleMode = v; save(); }

    public boolean isSmartItemRender() { return smartItemRender; }
    public void setSmartItemRender(boolean v) { smartItemRender = v; save(); }

    public boolean isAdaptiveAnimation() { return adaptiveAnimation; }
    public void setAdaptiveAnimation(boolean v) { adaptiveAnimation = v; save(); }

    public boolean isInvisibleChunkCache() { return invisibleChunkCache; }
    public void setInvisibleChunkCache(boolean v) { invisibleChunkCache = v; save(); }

    // Anti Freeze getters/setters
    public boolean isSmartGC() { return smartGC; }
    public void setSmartGC(boolean v) { smartGC = v; save(); }

    public boolean isChunkLoadQueue() { return chunkLoadQueue; }
    public void setChunkLoadQueue(boolean v) { chunkLoadQueue = v; save(); }

    public boolean isEntityUpdateSplit() { return entityUpdateSplit; }
    public void setEntityUpdateSplit(boolean v) { entityUpdateSplit = v; save(); }

    public boolean isTextureUploadScheduler() { return textureUploadScheduler; }
    public void setTextureUploadScheduler(boolean v) { textureUploadScheduler = v; save(); }

    public boolean isAsyncCacheBuilder() { return asyncCacheBuilder; }
    public void setAsyncCacheBuilder(boolean v) { asyncCacheBuilder = v; save(); }

    public boolean isFrameTimeStabilizer() { return frameTimeStabilizer; }
    public void setFrameTimeStabilizer(boolean v) { frameTimeStabilizer = v; save(); }

    public boolean isMicroFreezeShield() { return microFreezeShield; }
    public void setMicroFreezeShield(boolean v) { microFreezeShield = v; save(); }

    public boolean isResourcePreloader() { return resourcePreloader; }
    public void setResourcePreloader(boolean v) { resourcePreloader = v; save(); }

    public boolean isMemoryDefragmentation() { return memoryDefragmentation; }
    public void setMemoryDefragmentation(boolean v) { memoryDefragmentation = v; save(); }

    public boolean isFreezeMonitor() { return freezeMonitor; }
    public void setFreezeMonitor(boolean v) { freezeMonitor = v; save(); }

    public boolean isAdaptivePerformanceAI() { return adaptivePerformanceAI; }
    public void setAdaptivePerformanceAI(boolean v) { adaptivePerformanceAI = v; save(); }

    // Render
    public boolean isSafeRenderMode() { return safeRenderMode; }
    public void setSafeRenderMode(boolean v) { safeRenderMode = v; save(); }

    // HUD
    public boolean isShowHud() { return showHud; }
    public void setShowHud(boolean v) { showHud = v; save(); }

    // Tuning
    public int getTargetFps() { return targetFps; }
    public void setTargetFps(int v) { targetFps = Math.max(10, Math.min(300, v)); save(); }

    public int getGcIntervalTicks() { return gcIntervalTicks; }
    public void setGcIntervalTicks(int v) { gcIntervalTicks = Math.max(20, v); save(); }

    public int getEntitySplitBatchSize() { return entitySplitBatchSize; }
    public void setEntitySplitBatchSize(int v) { entitySplitBatchSize = Math.max(1, Math.min(50, v)); save(); }

    public long getFreezeThresholdMs() { return freezeThresholdMs; }
    public void setFreezeThresholdMs(long v) { freezeThresholdMs = Math.max(16L, v); save(); }

    public int getChunkQueueBatchSize() { return chunkQueueBatchSize; }
    public void setChunkQueueBatchSize(int v) { chunkQueueBatchSize = Math.max(1, Math.min(16, v)); save(); }

    public int getDefragIntervalTicks() { return defragIntervalTicks; }
    public void setDefragIntervalTicks(int v) { defragIntervalTicks = Math.max(200, v); save(); }
}
