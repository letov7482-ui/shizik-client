package com.shizik.client.optimization.fps;

import com.shizik.client.config.ShizikConfig;
import net.minecraft.util.math.ChunkPos;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Invisible Chunk Cache — кэширует данные о чанках вне поля зрения игрока.
 * При возвращении в зону видимости чанк отображается немедленно без рывка загрузки.
 */
public class InvisibleChunkCache {

    private static final int MAX_CACHE_SIZE = 256;
    private static final long ENTRY_TTL_MS = 30_000L;

    private final ShizikConfig config;
    private boolean enabled = false;

    private final Map<Long, CacheEntry> cache = new ConcurrentHashMap<>(MAX_CACHE_SIZE);

    public InvisibleChunkCache(ShizikConfig config) {
        this.config = config;
    }

    public void init() {
        enabled = config.isInvisibleChunkCache();
        if (enabled) {
            com.shizik.client.ShizikClient.LOGGER.info("[ChunkCache] Инициализирован, ёмкость: {}", MAX_CACHE_SIZE);
        }
    }

    public void markChunkCached(ChunkPos pos) {
        if (!enabled) return;
        long key = pos.toLong();
        cache.put(key, new CacheEntry(System.currentTimeMillis()));
        evictIfNeeded();
    }

    public boolean isChunkCached(ChunkPos pos) {
        if (!enabled) return false;
        CacheEntry entry = cache.get(pos.toLong());
        if (entry == null) return false;
        if (System.currentTimeMillis() - entry.timestamp > ENTRY_TTL_MS) {
            cache.remove(pos.toLong());
            return false;
        }
        return true;
    }

    public void invalidateChunk(ChunkPos pos) {
        cache.remove(pos.toLong());
    }

    public void clear() {
        cache.clear();
    }

    private void evictIfNeeded() {
        if (cache.size() <= MAX_CACHE_SIZE) return;
        long now = System.currentTimeMillis();
        // Удаляем просроченные
        cache.entrySet().removeIf(e -> now - e.getValue().timestamp > ENTRY_TTL_MS);
        // Если всё ещё слишком много — удаляем самые старые
        if (cache.size() > MAX_CACHE_SIZE) {
            cache.entrySet().stream()
                    .sorted(Map.Entry.comparingByValue(Comparator.comparingLong(e -> e.timestamp)))
                    .limit(cache.size() - MAX_CACHE_SIZE)
                    .forEach(e -> cache.remove(e.getKey()));
        }
    }

    public int getCacheSize() { return cache.size(); }
    public boolean isEnabled() { return enabled; }

    private record CacheEntry(long timestamp) {}
}
