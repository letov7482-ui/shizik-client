package com.shizik.client.optimization.antifreeze;

import com.shizik.client.config.ShizikConfig;
import com.shizik.client.util.PerformanceProfiler;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;

import java.util.*;

/**
 * Entity Update Split — распределяет обновления сущностей по нескольким тикам,
 * снижая пиковую нагрузку CPU в каждом отдельном тике.
 */
public class EntityUpdateSplitter {

    private final ShizikConfig config;
    private final PerformanceProfiler profiler;

    private boolean enabled = false;
    private int currentBatchIndex = 0;
    private final List<Integer> deferredEntityIds = new ArrayList<>();

    public EntityUpdateSplitter(ShizikConfig config, PerformanceProfiler profiler) {
        this.config = config;
        this.profiler = profiler;
    }

    public void init() {
        enabled = config.isEntityUpdateSplit();
        if (enabled) {
            com.shizik.client.ShizikClient.LOGGER.info("[EntitySplitter] Инициализирован, размер пакета: {}",
                    config.getEntitySplitBatchSize());
        }
    }

    public void onTick(MinecraftClient client) {
        if (!enabled || client.world == null) return;
        deferredEntityIds.clear();
        currentBatchIndex = (currentBatchIndex + 1) % Math.max(1, config.getEntitySplitBatchSize());
    }

    /**
     * Определяет, нужно ли откладывать обновление данной сущности в этом тике.
     * Обновление откладывается для части сущностей по round-robin схеме.
     */
    public boolean shouldDeferUpdate(Entity entity) {
        if (!enabled) return false;
        if (entity == null) return false;

        // Никогда не откладываем обновление игрока и связанных с ним сущностей
        MinecraftClient client = MinecraftClient.getInstance();
        if (client != null && (entity == client.player || entity == client.getCameraEntity())) {
            return false;
        }

        int batchSize = config.getEntitySplitBatchSize();
        if (batchSize <= 1) return false;

        int entitySlot = Math.abs(entity.getId()) % batchSize;
        return entitySlot != currentBatchIndex;
    }

    public boolean isEnabled() { return enabled; }
    public int getCurrentBatchIndex() { return currentBatchIndex; }
}
