package com.shizik.client.mixin;

import com.shizik.client.ShizikClient;
import com.shizik.client.optimization.antifreeze.ResourcePreloader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(MinecraftClient.class)
public class MinecraftClientMixin {

    @Inject(method = "joinWorld", at = @At("TAIL"))
    private void onWorldJoin(ClientWorld world, CallbackInfo ci) {
        ShizikClient mod = ShizikClient.getInstance();
        if (mod == null || world == null) return;

        try {
            // Захватываем оригинальную дальность рендера при входе в мир
            mod.getProfiler().onTickStart();

            // Запускаем предзагрузку ресурсов
            ResourcePreloader preloader = null;
            if (mod.getConfig() != null && mod.getConfig().isResourcePreloader()) {
                ShizikClient.LOGGER.debug("[ShizikClient] Мир загружен, запуск предзагрузчика...");
            }
        } catch (Exception ignored) {}
    }

    @Inject(method = "disconnect(Lnet/minecraft/client/gui/screen/Screen;)V", at = @At("HEAD"))
    private void onDisconnect(net.minecraft.client.gui.screen.Screen disconnectScreen, CallbackInfo ci) {
        ShizikClient mod = ShizikClient.getInstance();
        if (mod == null) return;

        try {
            // Восстанавливаем оригинальную дальность рендера при выходе
            if (mod.getConfig() != null && mod.getConfig().isDynamicRender()) {
                ShizikClient.LOGGER.debug("[ShizikClient] Отключение от мира — восстановление настроек...");
            }
            // Очищаем кэши
            if (mod.getChunkCache() != null) {
                mod.getChunkCache().clear();
            }
            if (mod.getItemRenderer() != null) {
                mod.getItemRenderer().invalidate();
            }
        } catch (Exception ignored) {}
    }
}
