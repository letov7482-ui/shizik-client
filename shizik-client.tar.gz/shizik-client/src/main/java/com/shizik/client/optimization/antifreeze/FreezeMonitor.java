package com.shizik.client.optimization.antifreeze;

import com.shizik.client.config.ShizikConfig;
import com.shizik.client.util.PerformanceProfiler;

import java.util.ArrayDeque;
import java.util.Deque;

/**
 * Freeze Monitor — отслеживает события зависаний (фризов) и микрофризов.
 * Ведёт историю для диагностики и предоставляет данные Adaptive AI.
 */
public class FreezeMonitor {

    private static final int HISTORY_SIZE = 20;

    private final ShizikConfig config;
    private final PerformanceProfiler profiler;

    private boolean enabled = false;
    private int freezeCount = 0;
    private int microFreezeCount = 0;
    private long lastFreezeTime = 0L;
    private long tickStartNs = 0L;

    private final Deque<FreezeEvent> history = new ArrayDeque<>(HISTORY_SIZE + 1);

    public FreezeMonitor(ShizikConfig config, PerformanceProfiler profiler) {
        this.config = config;
        this.profiler = profiler;
    }

    public void init() {
        enabled = config.isFreezeMonitor();
        if (enabled) {
            com.shizik.client.ShizikClient.LOGGER.info("[FreezeMonitor] Инициализирован, порог: {}мс",
                    config.getFreezeThresholdMs());
        }
    }

    public void onTick() {
        if (!enabled) return;

        if (tickStartNs > 0) {
            long durationMs = (System.nanoTime() - tickStartNs) / 1_000_000L;
            long threshold = config.getFreezeThresholdMs();

            if (durationMs >= threshold * 3) {
                freezeCount++;
                lastFreezeTime = System.currentTimeMillis();
                recordEvent(durationMs, FreezeType.FULL_FREEZE);
                com.shizik.client.ShizikClient.LOGGER.warn(
                        "[FreezeMonitor] Фриз обнаружен: {}мс (порог: {}мс)", durationMs, threshold);
            } else if (durationMs >= threshold) {
                microFreezeCount++;
                recordEvent(durationMs, FreezeType.MICRO_FREEZE);
                com.shizik.client.ShizikClient.LOGGER.debug(
                        "[FreezeMonitor] Микрофриз: {}мс", durationMs);
            }
        }
        tickStartNs = System.nanoTime();
    }

    private void recordEvent(long durationMs, FreezeType type) {
        history.addLast(new FreezeEvent(System.currentTimeMillis(), durationMs, type));
        while (history.size() > HISTORY_SIZE) {
            history.pollFirst();
        }
    }

    public int getFreezeCount() { return freezeCount; }
    public int getMicroFreezeCount() { return microFreezeCount; }
    public long getLastFreezeTime() { return lastFreezeTime; }
    public boolean hadRecentFreeze(long withinMs) {
        return lastFreezeTime > 0 && (System.currentTimeMillis() - lastFreezeTime) < withinMs;
    }
    public int getHistorySize() { return history.size(); }
    public boolean isEnabled() { return enabled; }

    public enum FreezeType { MICRO_FREEZE, FULL_FREEZE }

    public record FreezeEvent(long timestamp, long durationMs, FreezeType type) {}
}
