package com.shizik.client.optimization.fps;

import com.shizik.client.config.ShizikConfig;
import com.shizik.client.util.PerformanceProfiler;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;

import java.util.List;

/**
 * Battle Mode Optimization — обнаруживает боевой режим (враги рядом / игрок атакует)
 * и активирует упрощённый рендер частиц, уменьшает дальность прорисовки
 * для стабилизации FPS в бою.
 */
public class BattleModeOptimizer {

    private static final int BATTLE_CHECK_INTERVAL = 20;
    private static final int HOSTILE_SEARCH_RADIUS = 16;
    private static final int BATTLE_DECAY_TICKS = 60;

    private final ShizikConfig config;
    private final PerformanceProfiler profiler;

    private boolean enabled = false;
    private boolean battleActive = false;
    private int battleCooldown = 0;
    private int tickCounter = 0;
    private int nearbyHostileCount = 0;

    public BattleModeOptimizer(ShizikConfig config, PerformanceProfiler profiler) {
        this.config = config;
        this.profiler = profiler;
    }

    public void init() {
        enabled = config.isBattleMode();
        if (enabled) {
            com.shizik.client.ShizikClient.LOGGER.info("[BattleMode] Инициализирован");
        }
    }

    public void onTick(MinecraftClient client) {
        if (!enabled || client.world == null || client.player == null) return;

        tickCounter++;
        if (tickCounter < BATTLE_CHECK_INTERVAL) {
            if (battleActive && battleCooldown > 0) battleCooldown--;
            if (battleCooldown <= 0) battleActive = false;
            return;
        }
        tickCounter = 0;

        PlayerEntity player = client.player;
        Box searchBox = player.getBoundingBox().expand(HOSTILE_SEARCH_RADIUS);

        List<Entity> nearby = client.world.getOtherEntities(player, searchBox,
                e -> e instanceof HostileEntity);
        nearbyHostileCount = nearby.size();

        boolean wasAttacking = player.getAttackCooldownProgress(0f) < 0.5f;
        boolean hostileNearby = nearbyHostileCount > 0;

        if (hostileNearby || wasAttacking) {
            battleActive = true;
            battleCooldown = BATTLE_DECAY_TICKS;
        }
    }

    /** Возвращает, нужно ли упрощать эффект частиц в текущий момент. */
    public boolean shouldReduceParticles() {
        return enabled && battleActive && profiler.isHighLoad();
    }

    /** Возвращает, нужно ли отключить тени блоков. */
    public boolean shouldDisableEntityShadows() {
        return enabled && battleActive && nearbyHostileCount > 3;
    }

    public boolean isActive() { return battleActive; }
    public boolean isEnabled() { return enabled; }
    public int getNearbyHostileCount() { return nearbyHostileCount; }
}
