package com.shizik.client.optimization.antifreeze;

import com.shizik.client.config.ShizikConfig;
import com.shizik.client.optimization.fps.*;
import com.shizik.client.util.PerformanceProfiler;

/**
 * Adaptive Performance AI — центральная система автоматической настройки.
 * Анализирует метрики производительности и динамически включает/выключает
 * агрессивные оптимизации, адаптируясь под характеристики устройства.
 */
public class AdaptivePerformanceAI {

    private static final int EVAL_INTERVAL_TICKS = 60;

    private final ShizikConfig config;
    private final PerformanceProfiler profiler;

    private final DynamicRenderOptimizer dynamicRender;
    private final SmartEntityCulling entityCulling;
    private final BattleModeOptimizer battleMode;
    private final AdaptiveAnimation adaptiveAnimation;
    private final SmartGarbageCollector garbageCollector;
    private final FrameTimeStabilizer frameStabilizer;
    private final MicroFreezeShield microFreezeShield;

    private boolean enabled = false;
    private int tickCounter = 0;

    private PerformanceLevel currentLevel = PerformanceLevel.NORMAL;

    public enum PerformanceLevel {
        EXCELLENT, NORMAL, LOW, CRITICAL
    }

    public AdaptivePerformanceAI(ShizikConfig config, PerformanceProfiler profiler,
                                  DynamicRenderOptimizer dynamicRender,
                                  SmartEntityCulling entityCulling,
                                  BattleModeOptimizer battleMode,
                                  AdaptiveAnimation adaptiveAnimation,
                                  SmartGarbageCollector garbageCollector,
                                  FrameTimeStabilizer frameStabilizer,
                                  MicroFreezeShield microFreezeShield) {
        this.config = config;
        this.profiler = profiler;
        this.dynamicRender = dynamicRender;
        this.entityCulling = entityCulling;
        this.battleMode = battleMode;
        this.adaptiveAnimation = adaptiveAnimation;
        this.garbageCollector = garbageCollector;
        this.frameStabilizer = frameStabilizer;
        this.microFreezeShield = microFreezeShield;
    }

    public void init() {
        enabled = config.isAdaptivePerformanceAI();
        if (enabled) {
            com.shizik.client.ShizikClient.LOGGER.info("[AdaptiveAI] Инициализирован");
        }
    }

    public void onTick() {
        if (!enabled) return;
        tickCounter++;
        if (tickCounter < EVAL_INTERVAL_TICKS) return;
        tickCounter = 0;
        evaluate();
    }

    private void evaluate() {
        int fps = profiler.getCurrentFps();
        int target = config.getTargetFps();
        double frameMs = frameStabilizer.getSmoothedFrameMs();
        boolean spikeDetected = frameStabilizer.isSpikeDetected();
        boolean shieldActive = microFreezeShield.isShieldActive();

        PerformanceLevel newLevel = classifyPerformance(fps, target, frameMs, spikeDetected, shieldActive);

        if (newLevel != currentLevel) {
            com.shizik.client.ShizikClient.LOGGER.info(
                    "[AdaptiveAI] Уровень производительности: {} → {} (FPS: {}, frameMs: {:.1f})",
                    currentLevel, newLevel, fps, frameMs);
            currentLevel = newLevel;
            applyLevel(newLevel);
        }
    }

    private PerformanceLevel classifyPerformance(int fps, int target, double frameMs,
                                                   boolean spike, boolean shield) {
        if (fps <= 0) return PerformanceLevel.NORMAL;

        if (fps >= target * 1.2 && frameMs < 20.0 && !spike) return PerformanceLevel.EXCELLENT;
        if (fps >= target * 0.8 && frameMs < 30.0 && !shield) return PerformanceLevel.NORMAL;
        if (fps >= target * 0.5 || shield) return PerformanceLevel.LOW;
        return PerformanceLevel.CRITICAL;
    }

    private void applyLevel(PerformanceLevel level) {
        switch (level) {
            case EXCELLENT -> {
                // Восстанавливаем дальность рендера
                dynamicRender.restoreOriginal();
            }
            case NORMAL -> {
                // Нормальный режим — без изменений
            }
            case LOW -> {
                // Усиленная оптимизация
                dynamicRender.onFrameStart();
            }
            case CRITICAL -> {
                // Максимальная оптимизация
                dynamicRender.onFrameStart();
                garbageCollector.onFrameEnd();
            }
        }
    }

    public PerformanceLevel getCurrentLevel() { return currentLevel; }
    public boolean isEnabled() { return enabled; }
}
