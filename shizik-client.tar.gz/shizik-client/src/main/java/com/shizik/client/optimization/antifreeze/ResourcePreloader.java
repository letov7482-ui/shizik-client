package com.shizik.client.optimization.antifreeze;

import com.shizik.client.config.ShizikConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.Identifier;

import java.util.*;
import java.util.concurrent.*;

/**
 * Resource Preloader — предзагружает часто используемые ресурсы (текстуры, модели)
 * в фоновом потоке во время загрузки мира, чтобы снизить задержки
 * при первом обращении к ресурсам.
 */
public class ResourcePreloader {

    private static final List<String> PRIORITY_TEXTURES = List.of(
            "minecraft:textures/block/grass_block_top.png",
            "minecraft:textures/block/stone.png",
            "minecraft:textures/block/dirt.png",
            "minecraft:textures/entity/steve.png",
            "minecraft:textures/item/diamond_sword.png",
            "minecraft:textures/gui/widgets.png",
            "minecraft:textures/gui/icons.png"
    );

    private final ShizikConfig config;
    private boolean enabled = false;
    private boolean preloadComplete = false;
    private final Set<String> preloadedResources = new HashSet<>();
    private ExecutorService preloadExecutor;

    public ResourcePreloader(ShizikConfig config) {
        this.config = config;
    }

    public void init() {
        enabled = config.isResourcePreloader();
        if (enabled) {
            preloadExecutor = Executors.newSingleThreadExecutor(r -> {
                Thread t = new Thread(r, "ShizikClient-Preloader");
                t.setDaemon(true);
                t.setPriority(Thread.MIN_PRIORITY);
                return t;
            });
            com.shizik.client.ShizikClient.LOGGER.info("[ResourcePreloader] Инициализирован, {} приоритетных ресурсов",
                    PRIORITY_TEXTURES.size());
        }
    }

    /**
     * Запускает предзагрузку ресурсов. Вызывается после инициализации мира.
     */
    public void startPreload() {
        if (!enabled || preloadComplete || preloadExecutor == null) return;

        preloadExecutor.submit(() -> {
            try {
                MinecraftClient client = MinecraftClient.getInstance();
                if (client == null || client.getResourceManager() == null) return;

                for (String resourcePath : PRIORITY_TEXTURES) {
                    try {
                        String[] parts = resourcePath.split(":");
                        if (parts.length == 2) {
                            Identifier id = Identifier.of(parts[0], parts[1]);
                            client.getResourceManager().getResource(id).ifPresent(r -> {
                                try {
                                    r.getInputStream().close();
                                    preloadedResources.add(resourcePath);
                                } catch (Exception ignored) {}
                            });
                        }
                        Thread.sleep(5);
                    } catch (InterruptedException ie) {
                        Thread.currentThread().interrupt();
                        return;
                    } catch (Exception ignored) {}
                }
                preloadComplete = true;
                com.shizik.client.ShizikClient.LOGGER.info("[ResourcePreloader] Предзагрузка завершена: {} ресурсов",
                        preloadedResources.size());
            } catch (Exception e) {
                com.shizik.client.ShizikClient.LOGGER.warn("[ResourcePreloader] Ошибка предзагрузки: {}",
                        e.getMessage());
            }
        });
    }

    public void shutdown() {
        if (preloadExecutor != null && !preloadExecutor.isShutdown()) {
            preloadExecutor.shutdownNow();
        }
    }

    public boolean isPreloadComplete() { return preloadComplete; }
    public int getPreloadedCount() { return preloadedResources.size(); }
    public boolean isEnabled() { return enabled; }
}
