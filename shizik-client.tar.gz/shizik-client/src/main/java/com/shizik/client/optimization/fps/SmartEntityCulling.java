package com.shizik.client.optimization.fps;

import com.shizik.client.config.ShizikConfig;
import com.shizik.client.render.RenderCapabilityDetector;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Vec3d;

/**
 * Smart Entity Culling+ — пропускает рендер сущностей, не видимых игроку.
 * Учитывает угол зрения камеры, дистанцию и ограничения рендер-бэкенда.
 */
public class SmartEntityCulling {

    private static final double CULL_ANGLE_COS = Math.cos(Math.toRadians(100.0));
    private static final double MAX_CULL_DISTANCE_SQ = 64.0 * 64.0;

    private final ShizikConfig config;
    private final RenderCapabilityDetector renderDetector;
    private boolean enabled = false;

    public SmartEntityCulling(ShizikConfig config, RenderCapabilityDetector renderDetector) {
        this.config = config;
        this.renderDetector = renderDetector;
    }

    public void init() {
        enabled = config.isEntityCulling();
        if (enabled) {
            com.shizik.client.ShizikClient.LOGGER.info("[EntityCulling] Инициализирован");
        }
    }

    /**
     * Проверяет, нужно ли пропускать рендер данной сущности.
     * Вызывается из микса EntityRendererMixin.
     *
     * @return true если сущность нужно скрыть (не рендерить)
     */
    public boolean shouldCull(Entity entity) {
        if (!enabled) return false;
        if (entity == null) return false;

        MinecraftClient client = MinecraftClient.getInstance();
        if (client == null || client.player == null || client.gameRenderer == null) return false;
        if (entity == client.player) return false;
        if (entity == client.getCameraEntity()) return false;

        Vec3d cameraPos = client.gameRenderer.getCamera().getPos();
        Vec3d entityPos = entity.getPos();

        double distSq = cameraPos.squaredDistanceTo(entityPos);

        // Не скрываем ближние сущности (< 8 блоков)
        if (distSq < 64.0) return false;

        // Для дальних сущностей проверяем угол зрения
        if (distSq > MAX_CULL_DISTANCE_SQ) {
            return !isInFov(cameraPos, entityPos, client);
        }

        // Для средних — мягкая проверка (120 градусов вместо 100)
        if (distSq > 32.0 * 32.0) {
            return !isInFovWide(cameraPos, entityPos, client);
        }

        return false;
    }

    private boolean isInFov(Vec3d cameraPos, Vec3d entityPos, MinecraftClient client) {
        Vec3d lookVec = client.gameRenderer.getCamera().getHorizontalPlane();
        Vec3d toEntity = entityPos.subtract(cameraPos).normalize();
        double dot = lookVec.x * toEntity.x + lookVec.y * toEntity.y + lookVec.z * toEntity.z;
        return dot > CULL_ANGLE_COS;
    }

    private boolean isInFovWide(Vec3d cameraPos, Vec3d entityPos, MinecraftClient client) {
        Vec3d lookVec = client.gameRenderer.getCamera().getHorizontalPlane();
        Vec3d toEntity = entityPos.subtract(cameraPos).normalize();
        double dot = lookVec.x * toEntity.x + lookVec.y * toEntity.y + lookVec.z * toEntity.z;
        // ~120 deg
        return dot > -0.5;
    }

    public boolean isEnabled() { return enabled; }
}
