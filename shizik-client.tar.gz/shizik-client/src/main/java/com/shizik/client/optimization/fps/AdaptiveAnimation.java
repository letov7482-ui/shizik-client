package com.shizik.client.optimization.fps;

import com.shizik.client.config.ShizikConfig;
import com.shizik.client.util.PerformanceProfiler;
import net.minecraft.client.MinecraftClient;

/**
 * Adaptive Animation — при низком FPS снижает частоту обновления анимаций
 * сущностей и блоков для экономии CPU.
 */
public class AdaptiveAnimation {

    private static final int LOW_FPS_THRESHOLD_RATIO = 60;   // % от целевого
    private static final int VERY_LOW_FPS_THRESHOLD_RATIO = 40;

    private final ShizikConfig config;
    private final PerformanceProfiler profiler;

    private boolean enabled = false;
    private int animationUpdateInterval = 1;
    private long frameCounter = 0L;

    public AdaptiveAnimation(ShizikConfig config, PerformanceProfiler profiler) {
        this.config = config;
        this.profiler = profiler;
    }

    public void init() {
        enabled = config.isAdaptiveAnimation();
        if (enabled) {
            com.shizik.client.ShizikClient.LOGGER.info("[AdaptiveAnimation] Инициализирован");
        }
    }

    public void onFrameStart() {
        if (!enabled) return;
        frameCounter++;

        int currentFps = profiler.getCurrentFps();
        int target = MinecraftClient.getInstance() != null
                ? config.getTargetFps() : 60;

        if (currentFps == 0) {
            animationUpdateInterval = 1;
            return;
        }

        int ratio = currentFps * 100 / Math.max(1, target);

        if (ratio < VERY_LOW_FPS_THRESHOLD_RATIO) {
            animationUpdateInterval = 3;
        } else if (ratio < LOW_FPS_THRESHOLD_RATIO) {
            animationUpdateInterval = 2;
        } else {
            animationUpdateInterval = 1;
        }
    }

    /**
     * Проверяет, нужно ли обновлять анимацию в текущем кадре.
     */
    public boolean shouldUpdateAnimation() {
        if (!enabled) return true;
        return (frameCounter % animationUpdateInterval) == 0;
    }

    public int getAnimationUpdateInterval() { return animationUpdateInterval; }
    public boolean isEnabled() { return enabled; }
}
