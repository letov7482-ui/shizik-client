package com.shizik.client.mixin;

import com.shizik.client.ShizikClient;
import com.shizik.client.optimization.fps.SmartEntityCulling;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(EntityRenderer.class)
public class EntityRendererMixin<T extends Entity> {

    @Inject(
        method = "render",
        at = @At("HEAD"),
        cancellable = true
    )
    private void onEntityRender(T entity, float yaw, float tickProgress,
                                 MatrixStack matrices,
                                 VertexConsumerProvider vertexConsumers,
                                 int light,
                                 CallbackInfo ci) {
        ShizikClient mod = ShizikClient.getInstance();
        if (mod == null) return;

        try {
            SmartEntityCulling culling = mod.getEntityCulling();
            if (culling != null && culling.shouldCull(entity)) {
                ci.cancel();
            }
        } catch (Exception ignored) {
            // При любой ошибке — рендерим нормально
        }
    }
}
