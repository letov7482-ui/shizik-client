package com.shizik.client.mixin;

import com.shizik.client.ShizikClient;
import com.shizik.client.optimization.fps.AdaptiveAnimation;
import com.shizik.client.optimization.fps.DynamicRenderOptimizer;
import com.shizik.client.optimization.fps.SmartItemRenderer;
import com.shizik.client.optimization.antifreeze.MicroFreezeShield;
import com.shizik.client.optimization.antifreeze.TextureUploadScheduler;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.RenderTickCounter;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(GameRenderer.class)
public class GameRendererMixin {

    @Inject(method = "render", at = @At("HEAD"))
    private void onRenderFrameStart(RenderTickCounter tickCounter, boolean tick, CallbackInfo ci) {
        ShizikClient mod = ShizikClient.getInstance();
        if (mod == null) return;

        try {
            SmartItemRenderer itemRenderer = mod.getItemRenderer();
            if (itemRenderer != null) itemRenderer.onFrameStart();

            AdaptiveAnimation animation = mod.getAdaptiveAnimation();
            if (animation != null) animation.onFrameStart();

            TextureUploadScheduler texScheduler = mod.getTextureScheduler();
            if (texScheduler != null) texScheduler.onFrameStart();
        } catch (Exception ignored) {}
    }

    @Inject(method = "render", at = @At("TAIL"))
    private void onRenderFrameEnd(RenderTickCounter tickCounter, boolean tick, CallbackInfo ci) {
        ShizikClient mod = ShizikClient.getInstance();
        if (mod == null) return;

        try {
            TextureUploadScheduler texScheduler = mod.getTextureScheduler();
            if (texScheduler != null) texScheduler.flushBatch();

            MicroFreezeShield shield = null;
            // Оцениваем угрозу микрофриза после каждого кадра
            if (mod.getConfig() != null && mod.getConfig().isMicroFreezeShield()) {
                mod.getProfiler().onFrameRendered();
            }
        } catch (Exception ignored) {}
    }
}
