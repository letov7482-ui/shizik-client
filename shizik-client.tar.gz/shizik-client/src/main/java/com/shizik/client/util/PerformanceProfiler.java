package com.shizik.client.util;

import java.util.ArrayDeque;
import java.util.Deque;

/**
 * Профилировщик производительности. Отслеживает FPS, время тика и время кадра.
 */
public class PerformanceProfiler {

    private static final int SAMPLE_COUNT = 20;

    private final Deque<Long> frameTimes = new ArrayDeque<>(SAMPLE_COUNT + 1);
    private final Deque<Long> tickTimes = new ArrayDeque<>(SAMPLE_COUNT + 1);

    private long lastFrameTime = System.nanoTime();
    private long tickStartTime = 0L;
    private long lastFrameDeltaNs = 16_666_666L;

    private int currentFps = 0;
    private double averageFrameMs = 16.67;
    private double averageTickMs = 0.0;

    private volatile boolean isHighLoad = false;

    public void onTickStart() {
        tickStartTime = System.nanoTime();
    }

    public void onTickEnd() {
        if (tickStartTime == 0L) return;
        long tickDurationNs = System.nanoTime() - tickStartTime;
        addSample(tickTimes, tickDurationNs);
        averageTickMs = computeAverage(tickTimes) / 1_000_000.0;
        isHighLoad = averageTickMs > 45.0 || averageFrameMs > 33.0;
    }

    public void onFrameRendered() {
        long now = System.nanoTime();
        lastFrameDeltaNs = now - lastFrameTime;
        lastFrameTime = now;

        addSample(frameTimes, lastFrameDeltaNs);
        averageFrameMs = computeAverage(frameTimes) / 1_000_000.0;

        if (averageFrameMs > 0.0001) {
            currentFps = (int) Math.round(1000.0 / averageFrameMs);
        }
    }

    private void addSample(Deque<Long> deque, long value) {
        deque.addLast(value);
        while (deque.size() > SAMPLE_COUNT) {
            deque.pollFirst();
        }
    }

    private double computeAverage(Deque<Long> deque) {
        if (deque.isEmpty()) return 0.0;
        long sum = 0L;
        for (long v : deque) sum += v;
        return (double) sum / deque.size();
    }

    public int getCurrentFps() { return currentFps; }
    public double getAverageFrameMs() { return averageFrameMs; }
    public double getAverageTickMs() { return averageTickMs; }
    public long getLastFrameDeltaNs() { return lastFrameDeltaNs; }
    public boolean isHighLoad() { return isHighLoad; }
    public boolean isLowFps(int threshold) { return currentFps > 0 && currentFps < threshold; }
}
