package com.shizik.client.optimization.antifreeze;

import com.shizik.client.config.ShizikConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.ChunkPos;

import java.util.*;
import java.util.concurrent.PriorityBlockingQueue;

/**
 * Chunk Load Queue — управляет очерёдностью загрузки чанков.
 * Приоритизирует чанки ближе к игроку, чтобы сократить видимые рывки загрузки.
 */
public class ChunkLoadQueue {

    private final ShizikConfig config;
    private boolean enabled = false;

    private final PriorityBlockingQueue<ChunkRequest> queue = new PriorityBlockingQueue<>(64,
            Comparator.comparingDouble(r -> r.distanceSq));

    private int tickCounter = 0;
    private static final int PROCESS_INTERVAL = 5;

    public ChunkLoadQueue(ShizikConfig config) {
        this.config = config;
    }

    public void init() {
        enabled = config.isChunkLoadQueue();
        if (enabled) {
            com.shizik.client.ShizikClient.LOGGER.info("[ChunkLoadQueue] Инициализирован, размер пакета: {}",
                    config.getChunkQueueBatchSize());
        }
    }

    public void onTick(MinecraftClient client) {
        if (!enabled || client.world == null || client.player == null) return;

        tickCounter++;
        if (tickCounter < PROCESS_INTERVAL) return;
        tickCounter = 0;

        ChunkPos playerChunk = client.player.getChunkPos();

        // Обновляем приоритеты в очереди относительно текущей позиции
        List<ChunkRequest> snapshot = new ArrayList<>();
        queue.drainTo(snapshot);
        for (ChunkRequest req : snapshot) {
            req.distanceSq = playerChunk.getSquaredDistance(req.pos);
        }
        queue.addAll(snapshot);
    }

    public void enqueue(ChunkPos pos, MinecraftClient client) {
        if (!enabled) return;
        double distSq = 0.0;
        if (client != null && client.player != null) {
            distSq = client.player.getChunkPos().getSquaredDistance(pos);
        }
        queue.offer(new ChunkRequest(pos, distSq));
    }

    public Optional<ChunkPos> pollNext() {
        if (!enabled || queue.isEmpty()) return Optional.empty();
        ChunkRequest req = queue.poll();
        return req != null ? Optional.of(req.pos) : Optional.empty();
    }

    public int getQueueSize() { return queue.size(); }
    public boolean isEnabled() { return enabled; }

    private static class ChunkRequest {
        final ChunkPos pos;
        double distanceSq;

        ChunkRequest(ChunkPos pos, double distanceSq) {
            this.pos = pos;
            this.distanceSq = distanceSq;
        }
    }
}
