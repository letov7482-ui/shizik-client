package com.shizik.client.render;

import com.shizik.client.ShizikClient;
import org.lwjgl.opengl.GL11;

/**
 * Определяет возможности рендер-бэкенда и переключает безопасный режим
 * при обнаружении ограниченных или несовместимых рендеров.
 */
public class RenderCapabilityDetector {

    public enum Backend {
        OPENGL("OpenGL"),
        VULKAN_ZINK("Vulkan/Zink"),
        LTW("LTW"),
        KRYPTON("Krypton Wrapper"),
        MESA("Mesa"),
        VIRGL("VirGL"),
        TURNIP("Turnip"),
        FREEDRENO("Freedreno"),
        ADRENO("Adreno"),
        MALI("Mali"),
        POWERVR("PowerVR"),
        UNKNOWN("Unknown");

        private final String displayName;
        Backend(String displayName) { this.displayName = displayName; }
        public String getDisplayName() { return displayName; }
    }

    private Backend backend = Backend.UNKNOWN;
    private boolean safeMode = false;
    private boolean supportsInstancing = true;
    private boolean supportsVao = true;
    private boolean supportsComputeShaders = false;
    private String rawRendererString = "";
    private String rawVendorString = "";

    public void detect() {
        try {
            rawRendererString = safeGetString(GL11.GL_RENDERER);
            rawVendorString = safeGetString(GL11.GL_VENDOR);
            String version = safeGetString(GL11.GL_VERSION);

            backend = detectBackend(rawRendererString, rawVendorString, version);
            evaluateCapabilities(rawRendererString, rawVendorString, version);

            ShizikClient.LOGGER.info("[RenderDetector] Renderer: {}", rawRendererString);
            ShizikClient.LOGGER.info("[RenderDetector] Vendor: {}", rawVendorString);
            ShizikClient.LOGGER.info("[RenderDetector] Backend: {}", backend.getDisplayName());
            ShizikClient.LOGGER.info("[RenderDetector] Safe mode: {}", safeMode);
        } catch (Exception e) {
            ShizikClient.LOGGER.warn("[RenderDetector] Не удалось определить рендер-бэкенд, переход в безопасный режим: {}", e.getMessage());
            backend = Backend.UNKNOWN;
            safeMode = true;
            supportsInstancing = false;
            supportsVao = false;
        }
    }

    private String safeGetString(int name) {
        try {
            String s = GL11.glGetString(name);
            return s != null ? s.toLowerCase() : "";
        } catch (Exception e) {
            return "";
        }
    }

    private Backend detectBackend(String renderer, String vendor, String version) {
        if (renderer.contains("zink") || version.contains("zink")) return Backend.VULKAN_ZINK;
        if (renderer.contains("virgl")) return Backend.VIRGL;
        if (renderer.contains("ltw")) return Backend.LTW;
        if (renderer.contains("krypton")) return Backend.KRYPTON;
        if (renderer.contains("turnip") || renderer.contains("a6xx") || renderer.contains("a7xx")) return Backend.TURNIP;
        if (renderer.contains("freedreno") || renderer.contains("a5xx") || renderer.contains("a4xx")) return Backend.FREEDRENO;
        if (vendor.contains("qualcomm") || renderer.contains("adreno")) return Backend.ADRENO;
        if (vendor.contains("arm") || renderer.contains("mali")) return Backend.MALI;
        if (vendor.contains("imagination") || renderer.contains("powervr")) return Backend.POWERVR;
        if (vendor.contains("mesa") || renderer.contains("mesa") || renderer.contains("llvm")) return Backend.MESA;
        if (vendor.contains("intel") || vendor.contains("nvidia") || vendor.contains("amd") || vendor.contains("ati")) return Backend.OPENGL;
        return Backend.UNKNOWN;
    }

    private void evaluateCapabilities(String renderer, String vendor, String version) {
        switch (backend) {
            case VIRGL, LTW, KRYPTON -> {
                safeMode = true;
                supportsInstancing = false;
                supportsVao = false;
                supportsComputeShaders = false;
            }
            case VULKAN_ZINK -> {
                safeMode = false;
                supportsInstancing = true;
                supportsVao = true;
                supportsComputeShaders = isVersionAtLeast(version, 4, 3);
            }
            case TURNIP, ADRENO -> {
                safeMode = false;
                supportsInstancing = true;
                supportsVao = true;
                supportsComputeShaders = false;
            }
            case FREEDRENO, MALI, POWERVR -> {
                safeMode = true;
                supportsInstancing = false;
                supportsVao = false;
                supportsComputeShaders = false;
            }
            case MESA -> {
                safeMode = false;
                supportsInstancing = true;
                supportsVao = true;
                supportsComputeShaders = isVersionAtLeast(version, 4, 3);
            }
            case OPENGL -> {
                safeMode = false;
                supportsInstancing = true;
                supportsVao = true;
                supportsComputeShaders = isVersionAtLeast(version, 4, 3);
            }
            default -> {
                safeMode = true;
                supportsInstancing = false;
                supportsVao = false;
                supportsComputeShaders = false;
            }
        }
    }

    private boolean isVersionAtLeast(String versionStr, int major, int minor) {
        try {
            String[] parts = versionStr.split("[. ]");
            int maj = Integer.parseInt(parts[0]);
            int min = parts.length > 1 ? Integer.parseInt(parts[1].replaceAll("[^0-9]", "")) : 0;
            return maj > major || (maj == major && min >= minor);
        } catch (Exception e) {
            return false;
        }
    }

    public Backend getBackend() { return backend; }
    public String getBackendName() { return backend.getDisplayName(); }
    public boolean isSafeMode() { return safeMode; }
    public boolean supportsInstancing() { return supportsInstancing; }
    public boolean supportsVao() { return supportsVao; }
    public boolean supportsComputeShaders() { return supportsComputeShaders; }
    public String getRawRendererString() { return rawRendererString; }
    public String getRawVendorString() { return rawVendorString; }
}
