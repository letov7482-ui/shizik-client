package com.shizik.client;

import com.shizik.client.config.ShizikConfig;
import com.shizik.client.optimization.antifreeze.*;
import com.shizik.client.optimization.fps.*;
import com.shizik.client.render.RenderCapabilityDetector;
import com.shizik.client.util.PerformanceProfiler;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Shizik Client — точка входа мода.
 * Инициализирует все подсистемы оптимизации и регистрирует события.
 */
public class ShizikClient implements ClientModInitializer {

    public static final String MOD_ID = "shizik_client";
    public static final String MOD_NAME = "Shizik Client";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_NAME);

    private static ShizikClient instance;

    private ShizikConfig config;
    private RenderCapabilityDetector renderDetector;
    private PerformanceProfiler profiler;

    // FPS Boost подсистемы
    private DynamicRenderOptimizer dynamicRender;
    private SmartEntityCulling entityCulling;
    private BattleModeOptimizer battleMode;
    private SmartItemRenderer itemRenderer;
    private AdaptiveAnimation adaptiveAnimation;
    private InvisibleChunkCache chunkCache;

    // Anti Freeze подсистемы
    private SmartGarbageCollector garbageCollector;
    private ChunkLoadQueue chunkLoadQueue;
    private EntityUpdateSplitter entitySplitter;
    private TextureUploadScheduler textureScheduler;
    private AsyncCacheBuilder asyncCache;
    private FrameTimeStabilizer frameStabilizer;
    private MicroFreezeShield microFreezeShield;
    private ResourcePreloader resourcePreloader;
    private MemoryDefragmenter memoryDefrag;
    private FreezeMonitor freezeMonitor;
    private AdaptivePerformanceAI adaptiveAI;

    @Override
    public void onInitializeClient() {
        instance = this;
        LOGGER.info("[{}] Инициализация мода v1.0.0...", MOD_NAME);

        config = ShizikConfig.load();
        renderDetector = new RenderCapabilityDetector();
        profiler = new PerformanceProfiler();

        renderDetector.detect();
        LOGGER.info("[{}] Обнаруженный рендер-бэкенд: {}", MOD_NAME, renderDetector.getBackendName());
        if (renderDetector.isSafeMode()) {
            LOGGER.warn("[{}] Активирован безопасный режим для совместимости с устройством", MOD_NAME);
        }

        initFpsModules();
        initAntiFreezeModules();

        registerTickEvents();
        registerHudRenderer();

        LOGGER.info("[{}] Мод успешно инициализирован. FPS модули: {}, AntiFreeze модули: {}",
                MOD_NAME, getFpsModuleCount(), getAntiFreezeModuleCount());
    }

    private void initFpsModules() {
        dynamicRender = new DynamicRenderOptimizer(config, renderDetector, profiler);
        entityCulling = new SmartEntityCulling(config, renderDetector);
        battleMode = new BattleModeOptimizer(config, profiler);
        itemRenderer = new SmartItemRenderer(config, renderDetector);
        adaptiveAnimation = new AdaptiveAnimation(config, profiler);
        chunkCache = new InvisibleChunkCache(config);

        dynamicRender.init();
        entityCulling.init();
        battleMode.init();
        itemRenderer.init();
        adaptiveAnimation.init();
        chunkCache.init();
    }

    private void initAntiFreezeModules() {
        freezeMonitor = new FreezeMonitor(config, profiler);
        garbageCollector = new SmartGarbageCollector(config, profiler);
        chunkLoadQueue = new ChunkLoadQueue(config);
        entitySplitter = new EntityUpdateSplitter(config, profiler);
        textureScheduler = new TextureUploadScheduler(config, renderDetector);
        asyncCache = new AsyncCacheBuilder(config);
        frameStabilizer = new FrameTimeStabilizer(config, profiler);
        microFreezeShield = new MicroFreezeShield(config, freezeMonitor, profiler);
        resourcePreloader = new ResourcePreloader(config);
        memoryDefrag = new MemoryDefragmenter(config, profiler);
        adaptiveAI = new AdaptivePerformanceAI(config, profiler,
                dynamicRender, entityCulling, battleMode, adaptiveAnimation,
                garbageCollector, frameStabilizer, microFreezeShield);

        freezeMonitor.init();
        garbageCollector.init();
        chunkLoadQueue.init();
        entitySplitter.init();
        textureScheduler.init();
        asyncCache.init();
        frameStabilizer.init();
        microFreezeShield.init();
        resourcePreloader.init();
        memoryDefrag.init();
        adaptiveAI.init();
    }

    private void registerTickEvents() {
        ClientTickEvents.START_CLIENT_TICK.register(client -> {
            profiler.onTickStart();
        });

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.world == null) return;

            profiler.onTickEnd();

            entitySplitter.onTick(client);
            chunkLoadQueue.onTick(client);
            battleMode.onTick(client);
            garbageCollector.onTick();
            memoryDefrag.onTick();
            freezeMonitor.onTick();
            adaptiveAI.onTick();
        });
    }

    private void registerHudRenderer() {
        HudRenderCallback.EVENT.register((drawContext, tickDeltaManager) -> {
            MinecraftClient client = MinecraftClient.getInstance();
            if (client.options.debugEnabled) return;

            if (config.isShowHud()) {
                renderHud(drawContext, client);
            }
        });
    }

    private void renderHud(net.minecraft.client.gui.DrawContext drawContext, MinecraftClient client) {
        if (client.textRenderer == null) return;

        int fps = profiler.getCurrentFps();
        long usedMem = (Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory()) / (1024 * 1024);
        long maxMem = Runtime.getRuntime().maxMemory() / (1024 * 1024);
        String mode = adaptiveAI.isEnabled() ? "AI" : (battleMode.isActive() ? "Battle" : "Normal");

        int x = 2;
        int y = 2;
        int color = 0xFFFFFFFF;
        int shadow = 0x80000000;

        drawContext.drawTextWithShadow(client.textRenderer,
                String.format("FPS: %d", fps), x, y, color);
        drawContext.drawTextWithShadow(client.textRenderer,
                String.format("Mem: %dMB/%dMB", usedMem, maxMem), x, y + 10, color);
        drawContext.drawTextWithShadow(client.textRenderer,
                String.format("[SC] Mode: %s", mode), x, y + 20, color);
    }

    private int getFpsModuleCount() {
        int count = 0;
        if (dynamicRender.isEnabled()) count++;
        if (entityCulling.isEnabled()) count++;
        if (battleMode.isEnabled()) count++;
        if (itemRenderer.isEnabled()) count++;
        if (adaptiveAnimation.isEnabled()) count++;
        if (chunkCache.isEnabled()) count++;
        return count;
    }

    private int getAntiFreezeModuleCount() {
        int count = 0;
        if (garbageCollector.isEnabled()) count++;
        if (chunkLoadQueue.isEnabled()) count++;
        if (entitySplitter.isEnabled()) count++;
        if (textureScheduler.isEnabled()) count++;
        if (asyncCache.isEnabled()) count++;
        if (frameStabilizer.isEnabled()) count++;
        if (microFreezeShield.isEnabled()) count++;
        if (resourcePreloader.isEnabled()) count++;
        if (memoryDefrag.isEnabled()) count++;
        if (freezeMonitor.isEnabled()) count++;
        if (adaptiveAI.isEnabled()) count++;
        return count;
    }

    public static ShizikClient getInstance() { return instance; }
    public ShizikConfig getConfig() { return config; }
    public RenderCapabilityDetector getRenderDetector() { return renderDetector; }
    public PerformanceProfiler getProfiler() { return profiler; }
    public SmartEntityCulling getEntityCulling() { return entityCulling; }
    public InvisibleChunkCache getChunkCache() { return chunkCache; }
    public SmartItemRenderer getItemRenderer() { return itemRenderer; }
    public AdaptiveAnimation getAdaptiveAnimation() { return adaptiveAnimation; }
    public TextureUploadScheduler getTextureScheduler() { return textureScheduler; }
    public FrameTimeStabilizer getFrameStabilizer() { return frameStabilizer; }
}
