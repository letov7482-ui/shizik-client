package com.shizik.client.optimization.antifreeze;

import com.shizik.client.config.ShizikConfig;
import com.shizik.client.util.PerformanceProfiler;

/**
 * Memory Defragmenter — периодически запускает System.gc() + System.runFinalization()
 * в безопасный момент (не в середине рендера), снижая давление кучи Java
 * и предотвращая GC-паузы.
 */
public class MemoryDefragmenter {

    private final ShizikConfig config;
    private final PerformanceProfiler profiler;

    private boolean enabled = false;
    private int tickCounter = 0;
    private int defragCount = 0;
    private long lastDefragTime = 0L;

    public MemoryDefragmenter(ShizikConfig config, PerformanceProfiler profiler) {
        this.config = config;
        this.profiler = profiler;
    }

    public void init() {
        enabled = config.isMemoryDefragmentation();
        if (enabled) {
            com.shizik.client.ShizikClient.LOGGER.info("[MemoryDefrag] Инициализирован, интервал: {} тиков",
                    config.getDefragIntervalTicks());
        }
    }

    public void onTick() {
        if (!enabled) return;
        tickCounter++;

        if (tickCounter >= config.getDefragIntervalTicks()) {
            tickCounter = 0;
            runDefrag();
        }
    }

    private void runDefrag() {
        long now = System.currentTimeMillis();
        if (now - lastDefragTime < 60_000L) return; // не чаще раза в минуту

        Runtime rt = Runtime.getRuntime();
        long beforeFree = rt.freeMemory();

        System.gc();
        System.runFinalization();
        System.gc();

        long afterFree = rt.freeMemory();
        long freed = (afterFree - beforeFree) / (1024 * 1024);
        lastDefragTime = now;
        defragCount++;

        if (freed > 0) {
            com.shizik.client.ShizikClient.LOGGER.debug(
                    "[MemoryDefrag] Дефрагментация #{}: освобождено ~{}МБ", defragCount, freed);
        }
    }

    public int getDefragCount() { return defragCount; }
    public boolean isEnabled() { return enabled; }
}
